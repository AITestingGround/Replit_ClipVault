import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { SearchBar } from "@/components/search-bar";
import { VideoGrid } from "@/components/video-grid";
import { SubscriptionPopup } from "@/components/subscription-popup";
import { VideoImportModal } from "@/components/video-import-modal";
import { SocialAccountsModal } from "@/components/social-accounts-modal";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Video } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const { user, logoutMutation } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const videosQuery = useQuery({
    queryKey: ["/api/videos"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/videos");
      return res.json();
    },
  });

  const searchResultsQuery = useQuery({
    queryKey: ["/api/videos/search", searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return videosQuery.data || [];
      const res = await apiRequest("GET", `/api/videos/search?q=${encodeURIComponent(searchQuery)}`);
      return res.json();
    },
    enabled: searchQuery.trim().length > 0,
  });

  // Use search results when searching, otherwise use all videos
  const videos = searchQuery.trim().length > 0 ? searchResultsQuery.data : videosQuery.data || [];
  const isLoading = searchResultsQuery.isLoading || videosQuery.isLoading;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container flex h-14 items-center justify-between">
          <h1 className="font-semibold">ClipVault Dashboard</h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Welcome, {user?.username}
            </span>
            <Button variant="outline" onClick={() => logoutMutation.mutate()}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <div className="flex flex-col gap-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Your Videos</h2>
            <div className="flex gap-4">
              <SocialAccountsModal />
              <VideoImportModal />
            </div>
          </div>

          <div className="flex justify-center">
            <SearchBar onSearch={setSearchQuery} isLoading={isLoading} />
          </div>

          <VideoGrid videos={videos} loading={isLoading} />

          {videos && <SubscriptionPopup videoCount={videos.length} freeLimit={5} />}

        </div>
      </main>
    </div>
  );
}