
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { ThumbsUp, PlusCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { apiRequest } from "@/lib/api";

interface FeatureRequest {
  id: number;
  title: string;
  description: string;
  votes: number;
  createdAt: string;
  userHasVoted?: boolean;
}

export default function FeatureRequestsPage() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: featureRequests, isLoading } = useQuery({
    queryKey: ["/api/feature-requests"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/feature-requests");
      return res.json() as Promise<FeatureRequest[]>;
    },
  });

  const createFeatureRequestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/feature-requests", {
        title,
        description,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feature-requests"] });
      setTitle("");
      setDescription("");
      setShowSubmitForm(false);
      toast({
        title: "Feature request submitted",
        description: "Thank you for your suggestion!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit feature request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const voteForFeatureMutation = useMutation({
    mutationFn: async (featureId: number) => {
      const res = await apiRequest("POST", `/api/feature-requests/${featureId}/vote`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/feature-requests"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to vote for feature. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      toast({
        title: "Missing information",
        description: "Please provide both a title and description",
        variant: "destructive",
      });
      return;
    }
    createFeatureRequestMutation.mutate();
  };

  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Feature Requests & Ideas</h1>
          <p className="text-muted-foreground">
            Share your ideas and vote for features you'd like to see in ClipVault
          </p>
        </div>
        <Button
          onClick={() => setShowSubmitForm(!showSubmitForm)}
          className="flex items-center"
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          {showSubmitForm ? "Cancel" : "Share an Idea"}
        </Button>
      </div>

      {showSubmitForm && (
        <Card className="mb-8">
          <form onSubmit={handleSubmit}>
            <CardHeader>
              <CardTitle>Submit a Feature Request</CardTitle>
              <CardDescription>
                Share your idea for improving ClipVault
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Input
                  placeholder="Feature title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="mb-2"
                />
              </div>
              <div>
                <Textarea
                  placeholder="Describe your feature idea in detail..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button
                type="submit"
                disabled={createFeatureRequestMutation.isPending}
              >
                {createFeatureRequestMutation.isPending ? "Submitting..." : "Submit Feature Request"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-5 bg-muted rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : featureRequests?.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No feature requests yet. Be the first to suggest one!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {featureRequests?.map((feature) => (
            <Card key={feature.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle>{feature.title}</CardTitle>
                  <div className="bg-muted px-2 py-1 rounded-md flex items-center">
                    <ThumbsUp className="h-3.5 w-3.5 mr-1" />
                    <span className="text-sm">{feature.votes}</span>
                  </div>
                </div>
                <CardDescription>
                  {new Date(feature.createdAt).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{feature.description}</p>
              </CardContent>
              <CardFooter>
                <Button
                  variant={feature.userHasVoted ? "secondary" : "outline"}
                  size="sm"
                  onClick={() => voteForFeatureMutation.mutate(feature.id)}
                  disabled={voteForFeatureMutation.isPending}
                  className="ml-auto"
                >
                  <ThumbsUp className="h-4 w-4 mr-2" />
                  {feature.userHasVoted ? "Voted" : "Vote"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
