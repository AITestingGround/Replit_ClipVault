import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { SubscriptionTier } from "@/components/subscription-tier";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="container mx-auto py-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">ClipVault</h1>
        <div>
          {user ? (
            <Button asChild>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          ) : (
            <Button asChild>
              <Link href="/auth">Sign In</Link>
            </Button>
          )}
        </div>
      </header>
      <main className="flex-1 container mx-auto py-12 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-6">
            Organize and Search Your Video Library
          </h1>
          <p className="text-xl mb-8">
            Import videos from multiple platforms, generate transcripts
            automatically, and search through content with powerful keyword
            filtering.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button size="lg" asChild>
              <Link href="/auth">Get Started</Link>
            </Button>
          </div>
        </div>

        {/* Subscription Plans Section */}
        <section className="mt-12 mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Subscription Plans</h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <SubscriptionTier 
              type="free" 
              currentTier={false} 
            />
            <SubscriptionTier
              type="premium"
              currentTier={false}
              onUpgrade={() => {
                window.location.href = "/auth";
              }}
            />
          </div>
        </section>
      </main>
      <footer className="py-6 border-t">
        <div className="container mx-auto text-center text-muted-foreground">
          &copy; {new Date().getFullYear()} ClipVault. All rights reserved.
        </div>
      </footer>
    </div>
  );
}