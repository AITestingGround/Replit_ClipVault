
import { Home, Search, FileText, LogOut, ThumbsUp, Lightbulb } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation, useNavigate, Outlet } from "react-router-dom";
import { apiRequest } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export function AppShell() {
  const location = useLocation();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const handleLogout = async () => {
    await apiRequest("POST", "/api/logout");
    queryClient.clear();
    navigate("/auth");
  };

  return (
    <div className="grid min-h-screen grid-rows-[auto_1fr]">
      <header className="border-b px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-xl font-bold">ClipVault</h1>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout}>
          <LogOut className="h-4 w-4 mr-2" />
          Log out
        </Button>
      </header>

      <div className="grid grid-cols-[auto_1fr]">
        <nav className="border-r w-[240px] p-4">
          <div className="space-y-1">
            <Button
              variant={location.pathname === "/dashboard" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => navigate("/dashboard")}
            >
              <Home className="h-4 w-4 mr-2" />
              Dashboard
            </Button>
            <Button
              variant={location.pathname === "/videos" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => navigate("/videos")}
            >
              <FileText className="h-4 w-4 mr-2" />
              My Videos
            </Button>
            <Button
              variant={location.pathname === "/search" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => navigate("/search")}
            >
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
            <Button
              variant={location.pathname === "/feature-requests" ? "default" : "ghost"}
              className="w-full justify-start"
              onClick={() => navigate("/feature-requests")}
            >
              <ThumbsUp className="h-4 w-4 mr-2" />
              Feature Requests
            </Button>
          </div>

          <Separator className="my-4" />
        </nav>

        <main className="p-4">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
