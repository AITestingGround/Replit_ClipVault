import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertVideoSchema, type InsertVideo } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Loader2 } from "lucide-react";
import { useState } from "react";

export function VideoImportModal() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  // Enhanced validation schema
  const enhancedVideoSchema = insertVideoSchema.extend({
    sourceId: z.string()
      .min(1, "Video ID or URL is required")
      .refine((val) => {
        if (form.getValues("source").toLowerCase() === "youtube") {
          // Check if it's a valid YouTube URL or ID
          return /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})$/.test(val) || 
                 /^[a-zA-Z0-9_-]{11}$/.test(val);
        }
        // Add validation for other sources as needed
        return true;
      }, "Please enter a valid YouTube video URL or ID")
  });

  const form = useForm({
    resolver: zodResolver(enhancedVideoSchema),
    defaultValues: {
      title: "",
      description: "",
      source: "youtube",
      sourceId: "",
    },
    mode: "onChange", // Validate on change
  });

  const importMutation = useMutation({
    mutationFn: async (data: InsertVideo) => {
      const res = await apiRequest("POST", "/api/videos", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Success",
        description: "Video imported successfully",
      });
      setOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Import Video
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Import Video</DialogTitle>
          <DialogDescription>
            Enter the video details to import it into your library.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => importMutation.mutate(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="source"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Source</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="youtube" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="sourceId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Video ID or URL</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter video ID or full URL" />
                  </FormControl>
                  <FormDescription>
                    For YouTube, you can enter the video ID or the full URL
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
              type="submit" 
              className="w-full" 
              disabled={importMutation.isPending || !form.formState.isValid || Object.keys(form.formState.errors).length > 0}
            >
              {importMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Import Video
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}