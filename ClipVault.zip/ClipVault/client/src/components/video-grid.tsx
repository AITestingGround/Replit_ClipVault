import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Video } from "@shared/schema";
import { format } from "date-fns";
import { FileText } from "lucide-react";
import { useState } from "react";
import { TranscriptModal } from "./transcript-modal";

interface VideoGridProps {
  videos: Video[];
  loading?: boolean;
}

export function VideoGrid({ videos, loading }: VideoGridProps) {
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [transcriptModalOpen, setTranscriptModalOpen] = useState(false);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-4 bg-muted rounded w-3/4"></div>
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No videos found</p>
      </div>
    );
  }

  const handleTranscriptEdit = (video: Video) => {
    setSelectedVideo(video);
    setTranscriptModalOpen(true);
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {videos.map((video) => (
          <Card key={video.id} className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-lg">{video.title}</CardTitle>
              <div className="text-sm text-muted-foreground">
                {format(new Date(video.createdAt), "MMM d, yyyy")}
              </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-sm text-muted-foreground mb-2">{video.description}</p>
              {video.transcript && (
                <div className="text-sm mt-2">
                  <div className="font-semibold mb-1">Transcript Preview:</div>
                  <p className="line-clamp-3">{video.transcript}</p>
                </div>
              )}
              {!video.transcript && (
                <div className="text-sm mt-2 text-amber-500">
                  <p>No transcript available. Add one to make this video searchable.</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="border-t pt-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full" 
                onClick={() => handleTranscriptEdit(video)}
              >
                <FileText className="h-4 w-4 mr-2" />
                {video.transcript ? "Edit Transcript" : "Add Transcript"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      {selectedVideo && (
        <TranscriptModal 
          video={selectedVideo}
          open={transcriptModalOpen}
          onOpenChange={setTranscriptModalOpen}
        />
      )}
    </>
  );
}
