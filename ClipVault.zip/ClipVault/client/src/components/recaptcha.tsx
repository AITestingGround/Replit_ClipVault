
import { useState, useRef, useEffect } from "react";

interface ReCAPTCHAProps {
  onVerify: (token: string) => void;
  onExpire?: () => void;
}

export function ReCAPTCHA({ onVerify, onExpire }: ReCAPTCHAProps) {
  const [loaded, setLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const widgetId = useRef<number | null>(null);

  useEffect(() => {
    // Load reCAPTCHA script if not already loaded
    if (!window.grecaptcha) {
      const script = document.createElement("script");
      script.src = "https://www.google.com/recaptcha/api.js?render=explicit";
      script.async = true;
      script.defer = true;
      script.onload = () => setLoaded(true);
      document.head.appendChild(script);
      return () => {
        document.head.removeChild(script);
      };
    } else {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (loaded && containerRef.current && window.grecaptcha) {
      // Render reCAPTCHA widget
      widgetId.current = window.grecaptcha.render(containerRef.current, {
        sitekey: import.meta.env.VITE_RECAPTCHA_SITE_KEY || "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI", // Test key if not provided
        callback: onVerify,
        "expired-callback": onExpire,
      });
    }

    return () => {
      if (widgetId.current !== null && window.grecaptcha) {
        window.grecaptcha.reset(widgetId.current);
      }
    };
  }, [loaded, onVerify, onExpire]);

  return <div ref={containerRef} className="g-recaptcha my-4"></div>;
}

// Add types for global grecaptcha
declare global {
  interface Window {
    grecaptcha: {
      render: (
        container: HTMLElement,
        parameters: {
          sitekey: string;
          callback: (token: string) => void;
          "expired-callback"?: () => void;
        }
      ) => number;
      reset: (widgetId: number) => void;
    };
  }
}
