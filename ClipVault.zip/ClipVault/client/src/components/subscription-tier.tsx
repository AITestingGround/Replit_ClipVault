import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

import { Link } from "wouter";

interface SubscriptionTierProps {
  type: "free" | "premium";
  onUpgrade?: () => void;
  currentTier: boolean;
}

export function SubscriptionTier({ type, onUpgrade, currentTier }: SubscriptionTierProps) {
  const features = type === "premium" 
    ? [
        "Unlimited video imports",
        "Priority transcript processing",
        "Advanced search filters",
        "Analytics dashboard",
      ]
    : [
        "Limited video imports",
        "Basic transcription",
        "Basic search",
        "Standard support",
      ];

  return (
    <Card className={currentTier ? "border-primary" : ""}>
      <CardHeader>
        <CardTitle className="text-2xl">
          {type === "premium" ? "Premium" : "Free"}
          {currentTier && <span className="text-sm ml-2">(Current)</span>}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {features.map((feature, i) => (
            <div key={i} className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" />
              <span>{feature}</span>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        {type === "premium" && !currentTier && (
          <Button onClick={onUpgrade} className="w-full">
            {window.location.pathname === "/" ? "Sign Up for Premium" : "Upgrade to Premium"}
          </Button>
        )}
        {type === "free" && currentTier && (
          <Button variant="outline" disabled className="w-full">
            Current Plan
          </Button>
        )}
        {type === "free" && !currentTier && window.location.pathname === "/" && (
          <Button asChild variant="outline" className="w-full">
            <Link href="/auth">Sign Up Free</Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
