import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useState } from "react";
import { SiYoutube } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

export function SocialAccountsModal() {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleConnect = async (platform: string) => {
    try {
      setIsLoading(true);
      const res = await apiRequest("GET", `/api/auth/${platform.toLowerCase()}`);
      const data = await res.json();

      if (!data.authUrl) {
        throw new Error("No authorization URL received");
      }

      // Redirect to the OAuth authorization URL
      window.location.href = data.authUrl;
    } catch (error) {
      console.error('Social connect error:', error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : `Failed to connect to ${platform}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Connect Accounts</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Connect Video Platforms</DialogTitle>
          <DialogDescription>
            Connect your accounts to import videos automatically.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center justify-between px-4">
            <div className="flex items-center gap-3">
              <SiYoutube className="h-6 w-6 text-red-600" />
              <span>YouTube</span>
            </div>
            <Button
              variant="outline"
              onClick={() => handleConnect('youtube')}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                'Connect'
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}