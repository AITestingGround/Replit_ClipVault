
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Video } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface TranscriptModalProps {
  video: Video;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TranscriptModal({ video, open, onOpenChange }: TranscriptModalProps) {
  const [transcript, setTranscript] = useState(video.transcript || "");
  const queryClient = useQueryClient();

  const saveTranscriptMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/videos/${video.id}/transcript`, {
        transcript,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos/search"] });
      onOpenChange(false);
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit Transcript for: {video.title}</DialogTitle>
          <DialogDescription>
            Add or edit the transcript for your video. This will make the content searchable.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <Textarea
            placeholder="Paste or type the video transcript here..."
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            className="min-h-[200px]"
          />
        </div>

        <DialogFooter>
          <Button
            onClick={() => saveTranscriptMutation.mutate()}
            disabled={saveTranscriptMutation.isPending}
          >
            {saveTranscriptMutation.isPending ? "Saving..." : "Save Transcript"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
