
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

interface SubscriptionPopupProps {
  videoCount: number;
  freeLimit?: number;
}

export function SubscriptionPopup({ videoCount, freeLimit = 5 }: SubscriptionPopupProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    // Show popup when user exceeds free tier limit and is not premium
    if (user && !user.isPremium && videoCount > freeLimit) {
      setIsOpen(true);
    }
  }, [videoCount, user, freeLimit]);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Upgrade to Premium</DialogTitle>
          <DialogDescription>
            You have reached the limit of {freeLimit} videos on the free tier. Upgrade to premium to upload unlimited videos and access more features.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="bg-muted rounded-lg p-4">
            <h3 className="font-semibold mb-2">Premium features:</h3>
            <ul className="space-y-2 text-sm">
              <li>✓ Unlimited video imports</li>
              <li>✓ Priority transcript processing</li>
              <li>✓ Advanced search filters</li>
              <li>✓ Analytics dashboard</li>
            </ul>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => setIsOpen(false)} variant="outline">Not now</Button>
          <Button>Upgrade to Premium</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
