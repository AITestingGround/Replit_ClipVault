
import { Storage } from "./storage";
import { SpeechClient } from "@google-cloud/speech";
import ytdl from "ytdl-core";
import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

// Create a temporary directory for audio files
const tempDir = path.join(__dirname, "../temp");
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// Create Google Speech client using credentials from environment
const speechClient = new SpeechClient({
  credentials: JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON || "{}"),
});

export async function generateTranscript(
  videoSource: string,
  videoSourceId: string,
  videoTitle: string
): Promise<string> {
  try {
    // For YouTube videos, we can extract audio
    if (videoSource === "youtube") {
      console.log(`Generating transcript for YouTube video: ${videoSourceId}`);
      
      // 1. Download audio from YouTube
      const audioPath = await downloadYouTubeAudio(videoSourceId);
      
      // 2. Convert to FLAC (optimized for Google Speech-to-Text)
      const flacPath = await convertToFlac(audioPath);
      
      // 3. Transcribe the audio using Google Speech-to-Text
      const transcript = await transcribeWithGoogleSpeech(flacPath);
      
      // 4. Clean up temporary files
      fs.unlinkSync(audioPath);
      fs.unlinkSync(flacPath);
      
      return transcript;
    }
    
    // For other sources, return a message about manual transcription
    return `Automatic transcription is only available for YouTube videos. 
    Please add a manual transcript for this ${videoSource} video: "${videoTitle}".`;
  } catch (error) {
    console.error("Error generating transcript:", error);
    return `[TRANSCRIPTION ERROR] We encountered an error while trying to generate a transcript for "${videoTitle}".
    
    You can still add a manual transcript by clicking the "Edit Transcript" button.
    
    Error details: ${error instanceof Error ? error.message : String(error)}`;
  }
}

async function downloadYouTubeAudio(videoId: string): Promise<string> {
  const outputPath = path.join(tempDir, `${videoId}.mp3`);
  
  return new Promise((resolve, reject) => {
    // Download audio only from YouTube
    ytdl(`https://www.youtube.com/watch?v=${videoId}`, {
      filter: "audioonly",
      quality: "lowest" // Use lowest quality to speed up download
    })
    .pipe(fs.createWriteStream(outputPath))
    .on("finish", () => {
      resolve(outputPath);
    })
    .on("error", (err) => {
      reject(err);
    });
  });
}

async function convertToFlac(audioPath: string): Promise<string> {
  const flacPath = audioPath.replace('.mp3', '.flac');
  await execAsync(`ffmpeg -i "${audioPath}" -ar 16000 -ac 1 "${flacPath}"`);
  return flacPath;
}

async function transcribeWithGoogleSpeech(flacPath: string): Promise<string> {
  try {
    console.log("Transcribing with Google Speech-to-Text...");
    
    // Read file content
    const audioBytes = fs.readFileSync(flacPath).toString('base64');
    
    // Configure the request
    const audio = {
      content: audioBytes,
    };
    
    const config = {
      encoding: 'FLAC',
      sampleRateHertz: 16000,
      languageCode: 'en-US',
      enableAutomaticPunctuation: true,
    };
    
    const request = {
      audio: audio,
      config: config,
    };
    
    // Perform the transcription
    const [response] = await speechClient.recognize(request);
    const transcription = response.results
      .map(result => result.alternatives[0].transcript)
      .join('\n');
    
    console.log("Google Speech-to-Text transcription completed successfully");
    return transcription || "No speech detected.";
  } catch (error) {
    console.error("Error transcribing with Google Speech-to-Text:", error);
    throw new Error(`Google Speech-to-Text transcription failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
