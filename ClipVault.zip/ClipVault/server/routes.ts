import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { setupSocialAuth } from "./social-auth";
import { storage } from "./storage";
import { insertVideoSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);
  setupSocialAuth(app);

  // Video management endpoints
  app.post("/api/videos", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const videoData = insertVideoSchema.parse(req.body);
      
      // Handle URLs for various sources to extract IDs
      let sourceId = videoData.sourceId;
      
      if (videoData.source === "youtube" && sourceId.includes("youtube.com")) {
        // Extract YouTube video ID from URL
        try {
          const url = new URL(sourceId);
          const videoIdParam = url.searchParams.get("v");
          if (videoIdParam) {
            sourceId = videoIdParam;
          }
        } catch (error) {
          console.error("Error parsing YouTube URL:", error);
        }
      }
      
      const video = await storage.createVideo({
        ...videoData,
        sourceId,
        userId: req.user!.id,
      });
      
      // Try to fetch YouTube transcript if it's a YouTube video
      let transcript = null;
      if (video.source === "youtube") {
        try {
          // Import the YouTube transcript fetcher
          const { fetchYouTubeTranscript } = await import("./youtube-transcript");
          
          console.log(`Attempting to fetch transcript for YouTube video: ${video.sourceId}`);
          
          // Actually fetch transcript from YouTube
          transcript = await fetchYouTubeTranscript(video.sourceId);
          
          if (transcript) {
            console.log("YouTube transcript found and imported");
          }
        } catch (error) {
          console.error("Error fetching YouTube transcript:", error);
        }
      }
      
      // If no transcript was found, generate a real one using Whisper
      if (!transcript) {
        console.log("No existing transcript found, generating transcript automatically");
        
        try {
          // Import the transcription service
          const { generateTranscript } = await import("./transcription");
          
          // Generate transcript from the video using OpenAI Whisper
          transcript = await generateTranscript(video.source, video.sourceId, video.title);
          console.log("Transcript generated successfully with Whisper");
        } catch (error) {
          console.error("Error generating transcript:", error);
          transcript = `Unable to generate transcript automatically. You can add one manually.`;
        }
      }
      
      // Update the video with the generated transcript
      const updatedVideo = await storage.updateVideoTranscript(video.id, transcript);
      
      res.status(201).json(updatedVideo);
    } catch (error) {
      res.status(400).json({ error: "Invalid video data" });
    }
  });

  app.get("/api/videos", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const videos = await storage.getVideos(req.user!.id);
    res.json(videos);
  });

  app.get("/api/videos/search", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const query = req.query.q as string;
    if (!query) {
      return res.status(400).json({ error: "Search query required" });
    }

    const videos = await storage.searchVideos(query, req.user!.id);
    res.json(videos);
  });

  app.post("/api/videos/:id/transcript", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const videoId = parseInt(req.params.id);
    const { transcript } = req.body;

    if (!transcript) {
      return res.status(400).json({ error: "Transcript required" });
    }

    try {
      const video = await storage.updateVideoTranscript(videoId, transcript);
      res.json(video);
    } catch (error) {
      res.status(404).json({ error: "Video not found" });
    }
  });

  // Feature Request endpoints
  app.post("/api/feature-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { title, description } = req.body;
      if (!title || !description) {
        return res.status(400).json({ error: "Title and description are required" });
      }

      const featureRequest = await storage.createFeatureRequest({
        title,
        description,
        userId: req.user!.id,
      });

      res.status(201).json(featureRequest);
    } catch (error) {
      res.status(400).json({ error: "Invalid feature request data" });
    }
  });

  app.get("/api/feature-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const featureRequests = await storage.getFeatureRequests(req.user!.id);
    res.json(featureRequests);
  });

  app.get("/api/user/dashboard-metrics", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const metrics = await storage.getUserDashboardMetrics(req.user!.id);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Could not retrieve dashboard metrics" });
    }
  });

  app.post("/api/feature-requests/:id/vote", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const featureId = parseInt(req.params.id);
    try {
      const result = await storage.voteForFeature(featureId, req.user!.id);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Unable to vote for this feature" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}