import { User, InsertUser, Video, InsertVideo } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { like, or, and, eq, desc } from "drizzle-orm"; // Added import
import { sql } from "drizzle-orm";
import { count } from "drizzle-orm/pg-core";
import { users, videos, featureRequests, featureVotes } from "@shared/schema"; // Added import

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Video operations
  createVideo(video: InsertVideo & { userId: number }): Promise<Video>;
  getVideos(userId: number): Promise<Video[]>;
  searchVideos(query: string, userId: number): Promise<Video[]>; // Modified signature
  updateVideoTranscript(videoId: number, transcript: string): Promise<Video>;

  // Feature request methods
  createFeatureRequest(data: { title: string; description: string; userId: number }): Promise<any>;
  getFeatureRequests(): Promise<any[]>;
  voteForFeature(featureId: number, userId: number): Promise<{ voted: boolean }>;

  // Dashboard Metrics
  getUserDashboardMetrics(userId: number): Promise<{ totalVideos: number; topKeywords: { word: string; count: number }[] }>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private videos: Map<number, Video>;
  private currentUserId: number;
  private currentVideoId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.videos = new Map();
    this.currentUserId = 1;
    this.currentVideoId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, isPremium: false };
    this.users.set(id, user);
    return user;
  }

  async createVideo(video: InsertVideo & { userId: number }): Promise<Video> {
    const id = this.currentVideoId++;
    const newVideo: Video = {
      ...video,
      id,
      transcript: null,
      metadata: null,
      createdAt: new Date(),
    };
    this.videos.set(id, newVideo);
    return newVideo;
  }

  async getVideos(userId: number): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(
      (video) => video.userId === userId,
    );
  }

  async searchVideos(query: string, userId: number): Promise<Video[]> { // Modified implementation
    const searchTerm = query.toLowerCase();
    return Array.from(this.videos.values()).filter((video) => {
      return video.userId === userId && (
        video.title.toLowerCase().includes(searchTerm) ||
        (video.transcript && video.transcript.toLowerCase().includes(searchTerm))
      );
    });
  }

  async updateVideoTranscript(videoId: number, transcript: string): Promise<Video> {
    const video = this.videos.get(videoId);
    if (!video) throw new Error("Video not found");

    const updatedVideo = { ...video, transcript };
    this.videos.set(videoId, updatedVideo);
    return updatedVideo;
  }

  // Feature Request Methods
  private featureRequests = new Map<number, {
    id: number;
    title: string;
    description: string;
    userId: number;
    votes: number;
    createdAt: string;
    voterIds: Set<number>;
  }>();

  async createFeatureRequest(data: { title: string; description: string; userId: number }) {
    const id = this.featureRequests.size + 1;
    const featureRequest = {
      id,
      ...data,
      votes: 0,
      createdAt: new Date().toISOString(),
      voterIds: new Set<number>(),
    };
    
    this.featureRequests.set(id, featureRequest);
    
    // Return a clean version without the voterIds Set
    return {
      id: featureRequest.id,
      title: featureRequest.title,
      description: featureRequest.description,
      votes: featureRequest.votes,
      createdAt: featureRequest.createdAt,
    };
  }

  async getFeatureRequests(userId?: number) {
    const featureRequests = Array.from(this.featureRequests.values()).map(request => {
      const userHasVoted = userId ? request.voterIds.has(userId) : false;
      
      return {
        id: request.id,
        title: request.title,
        description: request.description,
        votes: request.votes,
        createdAt: request.createdAt,
        userHasVoted,
      };
    });
    
    // Sort by vote count (descending)
    return featureRequests.sort((a, b) => b.votes - a.votes);
  }

  async voteForFeature(featureId: number, userId: number) {
    const featureRequest = this.featureRequests.get(featureId);
    if (!featureRequest) {
      throw new Error("Feature request not found");
    }
    
    const hasVoted = featureRequest.voterIds.has(userId);
    
    if (hasVoted) {
      // User already voted, remove vote
      featureRequest.voterIds.delete(userId);
      featureRequest.votes--;
    } else {
      // Add user's vote
      featureRequest.voterIds.add(userId);
      featureRequest.votes++;
    }
    
    this.featureRequests.set(featureId, featureRequest);
    
    return {
      voted: !hasVoted,
      votes: featureRequest.votes
    };
  }


  // Dashboard Metrics
  async getUserDashboardMetrics(userId: number) {
    // This is a placeholder. A real implementation would interact with a database.
    return {
      totalVideos: this.videos.size,
      topKeywords: [],
    };
  }
}

export const storage = new MemStorage();