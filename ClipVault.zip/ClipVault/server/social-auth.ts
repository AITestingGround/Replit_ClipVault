import { Express } from "express";
import { storage } from "./storage";
import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

const youtube = google.youtube('v3');

// Get the host dynamically to work in all environments
const getHost = (req) => {
  const host = req.headers.host || 'localhost:3000';
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  return `${protocol}://${host}`;
};

// Create a new OAuth client for each request with the correct redirect URI
const createOAuth2Client = (req) => {
  return new OAuth2Client(
    process.env.YOUTUBE_CLIENT_ID,
    process.env.YOUTUBE_CLIENT_SECRET,
    `${getHost(req)}/api/auth/youtube/callback`
  );
};

export function setupSocialAuth(app: Express) {
  // YouTube OAuth endpoints
  app.get("/api/auth/youtube", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      if (!process.env.YOUTUBE_CLIENT_ID || !process.env.YOUTUBE_CLIENT_SECRET) {
        throw new Error("YouTube API credentials not configured");
      }

      const oauth2Client = createOAuth2Client(req);
      console.log('Generating YouTube auth URL with client ID:', process.env.YOUTUBE_CLIENT_ID);
      console.log('Redirect URI:', oauth2Client._redirectUri);

      const authUrl = oauth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: ['https://www.googleapis.com/auth/youtube.readonly'],
        include_granted_scopes: true,
        prompt: 'consent'
      });

      console.log('Generated YouTube auth URL:', authUrl);
      res.json({ authUrl });
    } catch (error) {
      console.error('Error generating YouTube auth URL:', error);
      res.status(500).json({ error: 'Failed to generate authorization URL' });
    }
  });

  // Handle YouTube OAuth callback
  app.get("/api/auth/youtube/callback", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const { code } = req.query;
      if (!code) {
        throw new Error("No authorization code received");
      }

      const oauth2Client = createOAuth2Client(req);
      console.log('Received YouTube auth code, exchanging for tokens');
      const { tokens } = await oauth2Client.getToken(code as string);
      oauth2Client.setCredentials(tokens);

      console.log('Fetching YouTube videos');
      const response = await youtube.search.list({
        auth: oauth2Client,
        part: ['snippet'],
        forMine: true,
        type: ['video'],
        maxResults: 50
      });

      console.log(`Found ${response.data.items?.length || 0} videos`);

      // Store videos in our database
      for (const item of response.data.items || []) {
        if (item.id?.videoId && item.snippet) {
          await storage.createVideo({
            userId: req.user!.id,
            title: item.snippet.title || 'Untitled',
            description: item.snippet.description || '',
            source: 'youtube',
            sourceId: item.id.videoId,
          });
        }
      }

      res.redirect('/dashboard');
    } catch (error) {
      console.error('YouTube OAuth error:', error);
      res.redirect('/dashboard?error=youtube_import_failed');
    }
  });
}