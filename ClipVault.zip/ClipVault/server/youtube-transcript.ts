
import axios from 'axios';
import { parse } from 'node-html-parser';

/**
 * Fetches a transcript for a YouTube video using video ID
 * 
 * @param videoId The YouTube video ID
 * @returns The transcript text or null if not available
 */
export async function fetchYouTubeTranscript(videoId: string): Promise<string | null> {
  try {
    // First, get the video page to extract available transcript languages
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const response = await axios.get(videoUrl);
    
    // Look for transcript data in the page source
    const html = response.data;
    const root = parse(html);
    
    // Try to extract captions from ytInitialPlayerResponse in the script
    const scripts = root.querySelectorAll('script');
    let captionTracks = [];
    
    for (const script of scripts) {
      const content = script.text || '';
      if (content.includes('ytInitialPlayerResponse')) {
        try {
          // Extract the JSON object
          const jsonStr = content.substring(
            content.indexOf('ytInitialPlayerResponse = ') + 'ytInitialPlayerResponse = '.length,
            content.lastIndexOf('};') + 1
          );
          
          const data = JSON.parse(jsonStr);
          
          // Extract caption tracks
          captionTracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
          break;
        } catch (error) {
          console.error('Error parsing YouTube player response:', error);
        }
      }
    }
    
    if (captionTracks.length === 0) {
      console.log(`No caption tracks found for video ${videoId}`);
      return null;
    }
    
    // Prefer English transcript, or use the first available one
    let captionTrack = captionTracks.find(track => 
      track.languageCode === 'en' || track.languageCode === 'en-US' || track.languageCode === 'en-GB'
    ) || captionTracks[0];
    
    // Get the transcript data
    const transcriptUrl = captionTrack.baseUrl;
    const transcriptResponse = await axios.get(transcriptUrl);
    const transcriptXml = transcriptResponse.data;
    
    // Parse the XML to extract text
    const transcriptRoot = parse(transcriptXml);
    const textElements = transcriptRoot.querySelectorAll('text');
    
    // Combine all text segments
    const transcriptText = textElements
      .map(element => element.text)
      .join(' ')
      // Clean up common XML entities
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
    
    return transcriptText || null;
  } catch (error) {
    console.error(`Error fetching YouTube transcript for ${videoId}:`, error);
    return null;
  }
}
